<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'العرف CMS كتلة المعلومات';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'يضيف كتل المعلومات المخصصة في متجرك.';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'حدث خطأ أثناء محاولة حفظ.';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_0366c7b2ea1bb228cd44aec7e3e26a3e'] = 'تحديث التكوين';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'مخصص جديد CMS كتلة';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'نص';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'رجوع الى القائمة';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'كتلة معرف';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'كتلة النص';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_ccf107a5d46c6501c9f2f4345400dc2e'] = 'متجر ID';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'إضافة';
