<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Własny blok informacyjny CMS';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Dodaje bloki z własną informacją w Twoim sklepie.';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Wystąpił błąd podczas próby zapisu.';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_0366c7b2ea1bb228cd44aec7e3e26a3e'] = 'Konfiguracja bloku została zaktualizowana.';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Nowy własny blok CMS';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Tekst';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Oszczędzać';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Powrót do listy';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'Blok ID';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Tekst bloku';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_ccf107a5d46c6501c9f2f4345400dc2e'] = 'ID sklepu';
$_MODULE['<{blockcmsinfo}leo_exist>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Dodaj nowy';
