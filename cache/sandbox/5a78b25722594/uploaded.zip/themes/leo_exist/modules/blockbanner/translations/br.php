<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_exist>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Bloco de banner';
$_MODULE['<{blockbanner}leo_exist>blockbanner_9d9becee392c0fbcc66ff4981b8ae2f7'] = 'Exibir um banner na parte superior da loja.';
$_MODULE['<{blockbanner}leo_exist>blockbanner_126b21ce46c39d12c24058791a236777'] = 'imagem inválida';
$_MODULE['<{blockbanner}leo_exist>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'um erro ocorreu ao enviar o arquivo';
$_MODULE['<{blockbanner}leo_exist>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Configurações atualizadas';
$_MODULE['<{blockbanner}leo_exist>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Configurações';
$_MODULE['<{blockbanner}leo_exist>blockbanner_89ca5c48bbc6b7a648a5c1996767484c'] = 'Bloco de imagem';
$_MODULE['<{blockbanner}leo_exist>blockbanner_296dce46079fc6cabe69b7e7edb25506'] = 'Pode fazer o upload do arquivo de imagem, ou digitar o link absoluto na opção \"Link da Imagem\" abaixo.';
$_MODULE['<{blockbanner}leo_exist>blockbanner_9ce38727cff004a058021a6c7351a74a'] = 'Link da imagem';
$_MODULE['<{blockbanner}leo_exist>blockbanner_5b79f7f033924a348f025924820988cb'] = 'Pode digitar o link absoluto da imagem, ou fazer o upload do arquivo de imagem na opção \"Imagem do Bloco\" acima.';
$_MODULE['<{blockbanner}leo_exist>blockbanner_18f2ae2bda9a34f06975d5c124643168'] = 'Descrição da Imagem';
$_MODULE['<{blockbanner}leo_exist>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Favor preencher com uma descrição curta, mas com significado';
$_MODULE['<{blockbanner}leo_exist>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
