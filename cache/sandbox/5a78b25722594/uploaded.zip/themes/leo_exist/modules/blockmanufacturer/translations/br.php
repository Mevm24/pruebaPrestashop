<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_bc3e73cfa718a3237fb1d7e1da491395'] = 'Bloco de fabricantes';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_71087c7035e626bd33c72ae9a7f042af'] = 'Apresenta um bloco de fabricantes/marcas';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_b15e7271053fe9dd22d80db100179085'] = 'Este módulo precisa ser ligado em uma coluna e seu tema não implementa nenhuma.';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_f8c922e47935b3b76a749334045d61cf'] = 'Existe um número de elementos inválido.';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'Por favor ative pelo menos uma lista do sistema';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_f38f5974cdc23279ffe6d203641a8bdf'] = 'Configurações atualizadas';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_f4f70727dc34561dfde1a3c529b6205c'] = 'Configurações';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_bfdff752293014f11f17122c92909ad5'] = 'Usar apenas como lista texto';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_a7c6946ecc7f4ed19c2691a1e7a28f97'] = 'Mostrar marcas em uma lista de texto.';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Ativado';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desativado';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_2eef734f174a02ae3d7aaafefeeedb42'] = 'Número de elementos para mostrar';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_b0fa976774d2acf72f9c62e9ab73de38'] = 'Usar uma lista suspensa';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_56353167778d1520bfecc70c470e6d8a'] = 'Para apresentar os fabricantes em uma lista suspensa';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Fabricantes';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_c70ad5f80e4c6f299013e08cabc980df'] = 'Mais sobre %s';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'Todos os fabricantes';
$_MODULE['<{blockmanufacturer}leo_exist>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'Nenhum fabricante';
