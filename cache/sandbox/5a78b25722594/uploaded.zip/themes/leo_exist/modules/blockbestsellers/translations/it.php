<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers-home_3cb29f0ccc5fd220a97df89dafe46290'] = 'I più venduti';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers-home_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Più';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers-home_4351cfebe4b61d8aa5efa1d020710005'] = 'Visualizza';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers-home_eae99cd6a931f3553123420b16383812'] = 'Tutte le migliori vendite';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers-home_adc570b472f54d65d3b90b8cee8368a9'] = 'Non ci sono migliori vendite in questo momento';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_9862f1949f776f69155b6e6b330c7ee1'] = 'Bloccano piú venduti';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_ed6476843a865d9daf92e409082b76e1'] = 'Aggiunge un blocco di esporre i prodotti top-seller del vostro negozio.';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_b15e7271053fe9dd22d80db100179085'] = 'Questo modulo ha bisogno di essere agganciato in una colonna e il tema non implementa uno';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornati';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_24ff4e4d39bb7811f6bdf0c189462272'] = 'Visualizza sempre questo blocco';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_84b0c5fdef19ab8ef61cd809f9250d85'] = 'Mostra il blocco anche se non migliori venditori sono disponibili.';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_1d0a2e1f62ccf460d604ccbc9e09da95'] = 'Vedi i prodotti più venduti';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'I più venduti';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Tutte le migliori vendite';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'Non ci sono migliori vendite in questo momento';
$_MODULE['<{blockbestsellers}leo_exist>tab_d7b2933ba512ada478c97fa43dd7ebe6'] = 'Migliori vendite';
$_MODULE['<{blockbestsellers}leo_exist>blockbestsellers-home_09a5fe24fe0fc9ce90efc4aa507c66e7'] = 'Non ci sono migliori vendite in questo momento.';
