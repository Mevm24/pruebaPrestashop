<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}leo_exist>blockcontact_df8f3e2cd8d1acbb2d1aa46a45045ec5'] = 'Blok informacji kontaktowych';
$_MODULE['<{blockcontact}leo_exist>blockcontact_318ed85b9852475f24127167815e85d9'] = 'Pozwala podać dodatkowe informacje o obsłudze klienta';
$_MODULE['<{blockcontact}leo_exist>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguracja zaktualizowana';
$_MODULE['<{blockcontact}leo_exist>blockcontact_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{blockcontact}leo_exist>blockcontact_7551cf1a985728fa2798db32c2ff7887'] = 'Numer telefonu';
$_MODULE['<{blockcontact}leo_exist>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{blockcontact}leo_exist>blockcontact_c9cc8cce247e49bae79f15173ce97354'] = 'Oszczędzać';
$_MODULE['<{blockcontact}leo_exist>blockcontact_9cfc9b74983d504ec71db33967591249'] = 'Skontaktuj się z nami';
$_MODULE['<{blockcontact}leo_exist>blockcontact_75858d311c84e7ba706b69bea5c71d36'] = 'Nasza infolinia dostępna jest 24 godziny na dobę, 7 dni w tygodniu.';
$_MODULE['<{blockcontact}leo_exist>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Telefon:';
$_MODULE['<{blockcontact}leo_exist>blockcontact_736c5a7e834b7021bfa97180fc453115'] = 'Skontaktuj się z naszą infolinią!';
$_MODULE['<{blockcontact}leo_exist>nav_9cfc9b74983d504ec71db33967591249'] = 'Kontakt z nami';
$_MODULE['<{blockcontact}leo_exist>nav_320abee94a07e976991e4df0d4afb319'] = 'Zadzwoń do nas:';
$_MODULE['<{blockcontact}leo_exist>nav_02d4482d332e1aef3437cd61c9bcc624'] = 'Kontakt z nami';
