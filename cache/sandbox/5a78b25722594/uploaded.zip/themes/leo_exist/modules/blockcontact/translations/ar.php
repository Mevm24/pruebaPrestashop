<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}leo_exist>blockcontact_df8f3e2cd8d1acbb2d1aa46a45045ec5'] = 'كتلة الاتصال';
$_MODULE['<{blockcontact}leo_exist>blockcontact_318ed85b9852475f24127167815e85d9'] = 'يسمح لك بإضافة معلومات إضافية حول متجرك خدمة العملاء.';
$_MODULE['<{blockcontact}leo_exist>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'تم تعديل الاعدادات بنحاج';
$_MODULE['<{blockcontact}leo_exist>blockcontact_f4f70727dc34561dfde1a3c529b6205c'] = 'الإعدادات';
$_MODULE['<{blockcontact}leo_exist>blockcontact_7551cf1a985728fa2798db32c2ff7887'] = 'رقم الهاتف';
$_MODULE['<{blockcontact}leo_exist>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'عنوان البريد';
$_MODULE['<{blockcontact}leo_exist>blockcontact_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{blockcontact}leo_exist>blockcontact_9cfc9b74983d504ec71db33967591249'] = 'الاتصال بنا';
$_MODULE['<{blockcontact}leo_exist>blockcontact_75858d311c84e7ba706b69bea5c71d36'] = 'فريق خدمة العملاء متواجد على مدار الساعة 24/7.';
$_MODULE['<{blockcontact}leo_exist>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'رقم الهاتف:';
$_MODULE['<{blockcontact}leo_exist>blockcontact_736c5a7e834b7021bfa97180fc453115'] = 'اتصل بفريق خدمة العملاء الآن!';
$_MODULE['<{blockcontact}leo_exist>nav_9cfc9b74983d504ec71db33967591249'] = 'الاتصال بنا';
$_MODULE['<{blockcontact}leo_exist>nav_320abee94a07e976991e4df0d4afb319'] = 'اتصل بنا الآن:';
$_MODULE['<{blockcontact}leo_exist>nav_02d4482d332e1aef3437cd61c9bcc624'] = 'اتصل بنا';
