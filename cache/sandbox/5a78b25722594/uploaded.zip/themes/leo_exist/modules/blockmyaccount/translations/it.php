<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccount}leo_exist>blockmyaccount_ecf3e4f8f34a293099620cc25d5b4d93'] = 'Blocco del mio account';
$_MODULE['<{blockmyaccount}leo_exist>blockmyaccount_ecf2ffd31994b3edea4b916011b08bfa'] = 'Visualizza un blocco con i link relativi all\'account utente.';
$_MODULE['<{blockmyaccount}leo_exist>blockmyaccount_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Il mio account';
$_MODULE['<{blockmyaccount}leo_exist>blockmyaccount_74ecd9234b2a42ca13e775193f391833'] = 'I miei ordini';
$_MODULE['<{blockmyaccount}leo_exist>blockmyaccount_89080f0eedbd5491a93157930f1e45fc'] = 'Restituzione delle mie merci';
$_MODULE['<{blockmyaccount}leo_exist>blockmyaccount_9132bc7bac91dd4e1c453d4e96edf219'] = 'Le mie note di credito';
$_MODULE['<{blockmyaccount}leo_exist>blockmyaccount_e45be0a0d4a0b62b15694c1a631e6e62'] = 'I miei indirizzi';
$_MODULE['<{blockmyaccount}leo_exist>blockmyaccount_63b1ba91576576e6cf2da6fab7617e58'] = 'Le mie informazioni personali';
$_MODULE['<{blockmyaccount}leo_exist>blockmyaccount_95d2137c196c7f84df5753ed78f18332'] = 'I miei buoni';
$_MODULE['<{blockmyaccount}leo_exist>blockmyaccount_c87aacf5673fada1108c9f809d354311'] = 'Esci';
